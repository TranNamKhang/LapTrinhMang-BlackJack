# Blackjack with Chat — Client/Server (Fixed)

This package includes a **console Blackjack game with chat** using TCP sockets. I've fixed the solution so it builds on **.NET 8 or .NET 9**, and made **host/port configurable** via arguments or environment variables.

## Requirements
- .NET SDK 8.0 or 9.0

## Build
```bash
dotnet build BlackJackGame.Client.sln -c Release
```

## Run the Server
Default port is **9000**.
```bash
# Linux/macOS
./run-server.sh        # or: BJ_PORT=9100 ./run-server.sh
# Windows
run-server.bat         # or: set BJ_PORT=9100 && run-server.bat
```
You may also run directly:
```bash
dotnet run --project Blackjack.Server.csproj -- 9000
```

## Run the Client
Defaults to **host=127.0.0.1** and **port=9000**.
```bash
# Linux/macOS
./run-client.sh                # or: BJ_HOST=192.168.1.100 BJ_PORT=9100 ./run-client.sh
# Windows
run-client.bat                 # or: set BJ_HOST=192.168.1.100 && set BJ_PORT=9100 && run-client.bat
```
You may also run directly:
```bash
dotnet run --project Blackjack.Client.csproj -- 127.0.0.1 9000
```

## Notes
- The solution file `BlackJackGame.Client.sln` includes **Shared**, **Server**, and **Client** projects.
- If you previously saw `Program does not contain a static 'Main'...`, that's addressed. Both **client** and **server** have a `static async Task Main(...)` entry point.
- Network settings are now configurable via **args** or **env vars** (`BJ_HOST`, `BJ_PORT`).

Good luck & have fun!
