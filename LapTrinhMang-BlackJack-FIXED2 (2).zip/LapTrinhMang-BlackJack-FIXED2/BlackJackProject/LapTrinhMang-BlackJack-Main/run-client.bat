@echo off
setlocal
set HOST=%BJ_HOST%
if "%HOST%"=="" set HOST=127.0.0.1
set PORT=%BJ_PORT%
if "%PORT%"=="" set PORT=9000
dotnet run --project Blackjack.Client.csproj -- %HOST% %PORT%
