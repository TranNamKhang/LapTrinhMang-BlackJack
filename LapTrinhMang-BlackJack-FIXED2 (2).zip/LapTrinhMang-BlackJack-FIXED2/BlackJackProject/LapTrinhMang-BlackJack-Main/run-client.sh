#!/usr/bin/env bash
set -e
HOST="${BJ_HOST:-127.0.0.1}"
PORT="${BJ_PORT:-9000}"
dotnet run --project Blackjack.Client.csproj -- "$HOST" "$PORT"
