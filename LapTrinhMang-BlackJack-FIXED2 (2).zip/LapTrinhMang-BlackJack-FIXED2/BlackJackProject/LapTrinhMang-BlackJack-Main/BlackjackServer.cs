﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Blackjack.Shared;

namespace Blackjack.Server
{
    public class BlackjackServer
    {
        private TcpListener listener;
        private readonly ConcurrentBag<TcpClient> clients = new();

        public void Start(int port = 5001)
        {
            listener = new TcpListener(IPAddress.Any, port);

            // FIX: Cho phép dùng lại port nếu còn bị kẹt (restart nhanh không lỗi)
            listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

            listener.Start();
            Console.WriteLine($"[SERVER] Listening on port {port}...");

            while (true)
            {
                var client = listener.AcceptTcpClient();
                clients.Add(client);
                Console.WriteLine("[SERVER] Client connected!");

                var thread = new Thread(() => HandleClient(client));
                thread.Start();
            }
        }

        private void HandleClient(TcpClient client)
        {
            using var stream = client.GetStream();
            using var reader = new StreamReader(stream, Encoding.UTF8);
            using var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

            writer.WriteLine("Welcome to Blackjack Server!");

            try
            {
                while (true)
                {
                    var line = reader.ReadLine();
                    if (line == null) break;

                    Console.WriteLine($"[SERVER] Received: {line}");

                    // broadcast đến tất cả client
                    foreach (var c in clients)
                    {
                        try
                        {
                            var w = new StreamWriter(c.GetStream(), Encoding.UTF8) { AutoFlush = true };
                            w.WriteLine($"[Broadcast] {line}");
                        }
                        catch { }
                    }
                }
            }
            catch
            {
                Console.WriteLine("[SERVER] Error handling client.");
            }

            Console.WriteLine("[SERVER] Client disconnected.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var server = new BlackjackServer();
            server.Start(); // giữ server chạy mãi
        }
    }
}
