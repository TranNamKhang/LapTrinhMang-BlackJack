using System.Windows;
using System.Windows.Controls;

namespace BlackJackGame.Client
{
    public partial class ChatWindow : Window
    {
        private BlackjackClient _client;

        public ChatWindow(BlackjackClient client)
        {
            InitializeComponent();
            _client = client;
            _client.OnMessageReceived += Client_OnMessageReceived;
        }

        private void SendChat_Click(object sender, RoutedEventArgs e)
        {
            string msg = ChatInput.Text.Trim();
            if (!string.IsNullOrEmpty(msg))
            {
                _client.SendMessage("CHAT:" + msg);
                ChatInput.Clear();
            }
        }

        private void Client_OnMessageReceived(string msg)
        {
            Dispatcher.Invoke(() =>
            {
                if (msg.StartsWith("CHAT:"))
                {
                    string chatMsg = msg.Substring(5);
                    ChatMessages.Children.Add(new TextBlock { Text = chatMsg, Margin = new Thickness(2) });
                }
            });
        }
    }
}
