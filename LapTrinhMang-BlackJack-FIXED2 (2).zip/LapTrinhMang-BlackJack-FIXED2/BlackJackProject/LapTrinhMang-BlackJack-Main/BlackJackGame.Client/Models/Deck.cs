﻿using BlackJackGame.Client.Models;
using System;

namespace BlackJackGame
{
    public class Deck
    {
        internal Card DrawCard()
        {
            throw new NotImplementedException();
        }
    }
}