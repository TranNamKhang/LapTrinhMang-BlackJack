@echo off
setlocal
set PORT=%BJ_PORT%
if "%PORT%"=="" set PORT=9000
dotnet run --project Blackjack.Server.csproj -- %PORT%
