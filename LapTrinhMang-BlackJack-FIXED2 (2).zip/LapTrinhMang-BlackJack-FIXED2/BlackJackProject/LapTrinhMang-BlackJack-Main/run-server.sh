#!/usr/bin/env bash
set -e
PORT="${BJ_PORT:-9000}"
dotnet run --project Blackjack.Server.csproj -- "$PORT"
