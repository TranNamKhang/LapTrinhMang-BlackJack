﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Blackjack.Shared;

namespace Blackjack.Client
{
    public class BlackjackClient
    {
        private TcpClient client;
        private StreamReader reader;
        private StreamWriter writer;

        public void Run(string host = "127.0.0.1", int port = 5000)
        {
            try
            {
                client = new TcpClient(host, port);
                var stream = client.GetStream();
                reader = new StreamReader(stream, Encoding.UTF8);
                writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

                Console.WriteLine("[CLIENT] Connected to server.");

                // thread lắng nghe server
                new Thread(Listen).Start();

                // nhập từ bàn phím gửi lên server
                while (true)
                {
                    string msg = Console.ReadLine();
                    if (msg == "exit") break;
                    writer.WriteLine(msg);
                }

                client.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CLIENT] Error: {ex.Message}");
            }
        }

        private void Listen()
        {
            try
            {
                while (true)
                {
                    var line = reader.ReadLine();
                    if (line == null) break;
                    Console.WriteLine(line);
                }
            }
            catch { }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var client = new BlackjackClient();
            client.Run();
        }
    }
}
